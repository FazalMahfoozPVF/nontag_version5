import RPi.GPIO as GPIO
import time #import sleep


sensor=18
ch1=12
ch2=16
#buzzer=37

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(sensor,GPIO.IN)# pin for buzzer
GPIO.setup(ch1,GPIO.OUT)
GPIO.setup(ch2,GPIO.OUT)
#while True:

if GPIO.input(sensor)== 1:
    file=open("/home/pi/Configuration/buzzer_pin.txt",'w')#path for reading cpu serial number
    file.write(str(ch1))
    file.close()
    #GPIO.output(ch1,GPIO.HIGH)
    #GPIO.output(ch2,GPIO.LOW)
    
if GPIO.input(sensor)== 0:
    file=open("/home/pi/Configuration/buzzer_pin.txt",'w')#path for reading cpu serial number
    file.write(str(ch2))
    file.close()
    #GPIO.output(ch1,GPIO.LOW)
    #GPIO.output(ch2,GPIO.HIGH)
