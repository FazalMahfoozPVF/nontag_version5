import os
class modal():

	def measure_temp():
		temp=os.popen("vcgencmd measure_temp").readline()
		return (temp.replace("temp=",""))
	
	def getserial():
		cpuserial="0000000000000000"
		try:
			f=open('/proc/cpuinfo','r')
			for line in f:
				if line[0:6]=='Serial':
					cpuserial=line[10:26]
			f.close()
		except:
			cpuserial="ERROR0000000"
		return cpuserial