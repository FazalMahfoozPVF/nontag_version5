import serial
import sys
from modal import *
#from buzzer_condition import *
from buzzer import *
import time
import subprocess
import re
import calendar;
import datetime
import os
#from buzzer_condition import *
#import mysql.connector

'''
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="password",
  database="aman_mis"
)
'''


file=open("/home/pi/Configuration/dump.txt",'r')#path for reading cpu serial number
cpu_serial=file.read();
file.close()

file2=open("/home/pi/Configuration/range_high.txt",'r')#path for reading cpu serial number
range_high=float(file2.read());
file2.close()

file3=open("/home/pi/Configuration/range_low.txt",'r')#path for reading cpu serial number
range_low=float(file3.read());
file3.close()


file4=open("/home/pi/Configuration/current_time.txt",'r')#path for reading cpu serial number
equi_Stop_time=file4.read();
file4.close()

file7=open("/home/pi/Configuration/Serial.txt",'r')#path for reading cpu serial number
serial_number=file7.read();
file7.close()

	
def controller():
    ts = time.time()
    s =  datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y %H:%M:%S')
    t =  datetime.datetime.fromtimestamp(ts).strftime('%H-%M-%S')
    d =  datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')

    ser = serial.Serial("/dev/serial0",115200)
    i=0
    a=['','','','','','','','','','']
    print(modal.getserial())
    if cpu_serial==modal.getserial() :
        
        #if folder==[]:
        path_exist = str(subprocess.check_output("sudo find /home/pi/Configuration/Tagsheets -name \""+d+"\" ", shell=True));
        my_path=str("/home/pi/Documents/Dump2/dump/Tagsheets/"+d+"\n")
        print(path_exist)
        try:
            os.system('sudo mkdir /home/pi/Configuration/Tagsheets/'+d)
        except mkdir as error : 
            pass

        os.system('sudo chmod a+r+w /home/pi/Configuration/Tagsheets/'+d)

        worksheet="/home/pi/Configuration/Tagsheets/"+d+"/Non-Tag-"+d+".txt"
        f = open(worksheet,'a')
        f.write("Equipment Stop Time:"+equi_Stop_time+"\n\n\nEquipment Start Time:"+t+"\nSerial No:"+serial_number+"\n    Date       Time     Distance of Object\n")
        f.close()
        while True:
            if ser.inWaiting() > 0:
                folder=os.listdir('/media/pi')
                #print(folder)
                in_byte=ser.read()
                x=int.from_bytes(in_byte, byteorder=sys.byteorder)
                
                if folder==[]:
                    #tttt = time.time()
                    #tt1 =  datetime.datetime.fromtimestamp(tttt).strftime('%H-%M-%S')
                    if in_byte!=b'\xaa' and in_byte!=b'U' and in_byte!=b'\n':
                        a[i]=x
                        i+=1
                        
                    if in_byte==b'U':
                        if a[0]==12 and a[1]==7:
                            dist= ((a[4])*256+a[5])*0.01
                            velo=((a[7]*256+a[8])*0.05)-35
                            x="{0:.2f}".format(dist)
                            print("Distance of object:"+str(x))

                            if dist> (range_low) and dist<(range_high) :
                                pin.buzzer_blow()
                                ttt = time.time()
                                tt =  datetime.datetime.fromtimestamp(ttt).strftime('%H-%M-%S')
                                dt =  datetime.datetime.fromtimestamp(ttt).strftime('%d-%m-%Y')
                                f=open(worksheet,'a')
                                f.write(str(dt)+"    "+str(tt)+"        "+str(x)+"\n")
                                f.close()
                                
                                file5=open("/home/pi/Configuration/current_time.txt",'w')#path for reading cpu serial number
                                file5.write(tt);
                                file5.close()


                            if dist<=(range_low) and dist>=(range_high):
                                pin.buzzer_off()
                            i=0
                        else:
                            pin.buzzer_off()
                            i=0
                    #else:
                     #   i=0
                else:
                   # print("line 8")
                    pin.buzzer_blow()

                    x=open("/home/pi/Configuration/current_time.txt",'r')#path for reading cpu serial number
                    equi_Stop_time1=x.read();
                    x.close()

                    worksheet1="/home/pi/Configuration/Tagsheets/"+d+"/Non-Tag-"+d+".txt"
                    f = open(worksheet1,'a')
                    f.write("\nEquipment Stop Time:"+equi_Stop_time1)
                    f.close()

                    y=open("/home/pi/Configuration/current_time.txt",'w')#path for reading cpu serial number
                    y.write(" ");
                    y.close()

                    cmd='sudo rsync -avx /home/pi/Configuration/Tagsheets/ /media/pi/'+folder[0]#+"/"
                    os.system(cmd)
                    folder1=os.listdir('/home/pi/Configuration/Tagsheets/')
                    folder_len=(len(folder1))
                   # print(folder1)
                   # print(folder_len,type(folder_len))

                    cmd2="sudo umount /media/pi/"+folder[0]
                    os.system(cmd2)
                    #for x in range(folder_len):
                     #   print (x,type(x))
                      #  cmd3="sudo rm -r theDir /home/pi/Configuration/Tagsheets/"+folder1[(x)]
                     #   os.system(cmd3)
                    
                    #pin.buzzer_off()
                    #if folder!=[]
                    cmd4="sudo rm -r theDir /media/pi/"+folder[0]
                    os.system(cmd4)
                    time.sleep(3)
                    pin.buzzer_off()
                    os.system('sudo reboot')                    
    if cpu_serial!=modal.getserial() :
            print('Please put this in right Pi!')
            time.sleep(2)
            os.system('sudo reboot')
controller()		


