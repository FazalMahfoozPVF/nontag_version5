from modal import *
import os
import time
length= os.lstat('/home/pi/Configuration/dump.txt').st_size
cpu_serial=modal.getserial()
if length==0:
    file=open("/home/pi/Configuration/dump.txt",'w')#path for reading cpu serial number
    #cpu_serial=file.read();
    
    file.write(modal.getserial())
    file.close()
    print('The device is ready')
    os.system("echo \'The device is ready\'")
    time.sleep(10)

