import RPi.GPIO as GPIO
import time #import sleep

buzzer=18

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(buzzer,GPIO.OUT)# pin for buzzer

class pin():	
	def buzzer_blow():
		GPIO.output(buzzer,GPIO.HIGH)
		#time.sleep(0.0001)

	
	def buzzer_off():
		GPIO.output(buzzer,GPIO.LOW)
		#time.sleep(0.0001)
