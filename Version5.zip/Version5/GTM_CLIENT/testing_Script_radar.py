# -*- coding: utf-8 -*-
#‎p ('بسم الله')
'''           
	Company: Perfect Vision Tech
	Developer: Fazal Mahfooz
	Project: Radar Version 4
	Description: Integrated Nano Radar and Getting Values with respect to target
                     distance and speed with text data giving when we connect pendrive
	Next Target:
	Date: 06 Nov 2019 
	Place: Dammam,KSA
'''


import serial
import sys
#from modal import *
from buzzer import *
import time
import subprocess
import re
import calendar;
import datetime
import os
#import Client_1
#ser = serial.Serial("/dev/serial0",115200)
#os.system("sudo invoke-rc.d bluetooth restart")
def testing_Script():
    ts = time.time()
    f=0
    s =  datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y %H:%M:%S')
    t =  datetime.datetime.fromtimestamp(ts).strftime('%H-%M-%S')
    d =  datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y')
    ser = serial.Serial("/dev/serial0",115200)
    y=0
    i=0
    a=['','','','','','','','','','']
    #print(ser)
    worksheet="/home/pi/Documents/GTM_CLIENT/dump/TestData/test.txt"
    while 1:
        if ser.inWaiting() > 0:
            in_byte=ser.read()
            #print(in_byte)
            x=int.from_bytes(in_byte, byteorder=sys.byteorder)
            if in_byte!=b'\xaa' and in_byte!=b'U' and in_byte!=b'\n':
                a[i]=x
                i+=1
                #Client_1.sendTomasterInTesting()
                #y+=1
                #print("yaha h1",y)
                #return "no-tag"
                
            if in_byte==b'U':
                #print(i)
               # print(a)
                if  a[0]==12 and a[1]==7:
                    dist= ((a[4])*256+a[5])*0.01
                    velo=((a[7]*256+a[8])*0.05)-35
                    x="{0:.2f}".format(dist)
                    print("Distance of object:"+str(x))
                    if(dist<6):
                        pin.buzzer_blow()
                        ttt = time.time()
                        tt =  datetime.datetime.fromtimestamp(ttt).strftime('%H-%M-%S')
                        dt =  datetime.datetime.fromtimestamp(ttt).strftime('%d-%m-%Y')
                        f=open(worksheet,'w')
                        f.write(str(dt)+"|"+str(tt)+"|"+str(x))#+"                "+str(t)+"             "+str(tt)+"\n")
                        f.close()
                        break
                    
                        #os.system("sudo python3 /home/pi/Documents/GTM_CLIENT/testing_Script_radar.py")
                        #Client_1.sendTomasterInTesting()
                        #y+=1
                        #return str(dt),str(tt),str(x)
                    if(dist>=6):
                        print("here")
                        pin.buzzer_off()
                        #Client_1.sendTomasterInTesting()
                        #y+=1
                        #return "no-tag"
                    i=0
                else:
                    pin.buzzer_off()
                    i=0
                    #Client_1.sendTomasterInTesting()
                    #y+=1
                    #print("yaha 2",y)
                    #return "no-tag"


file_st=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'r')
status=file_st.read()
file_st.close()
if status=="Untested":
    #sendTomaster()
    print("Untested")
if status=="under_test":
    print("Under test")
    #sendTomasterInTesting()
    #testing_Script()                  
##try:
##    testing_Script()		
##except:
##    print("Coming out")
