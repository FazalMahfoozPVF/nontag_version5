
#!/usr/bin/env python3
from time import sleep
import socket
from modal import *
import clientConfiguration as clcon
import generalConfig
import serial
import subprocess


from multiprocessing import Process
os.system("sudo invoke-rc.d bluetooth restart")

def setHostname(newhostname):
    print("aya")
    with open('/etc/hosts', 'r') as file:
        data = file.readlines()
        data[5] = '127.0.1.1       ' + newhostname
    with open('temp.txt', 'w') as file:
        file.writelines( data )
    os.system('sudo mv temp.txt /etc/hosts')
    with open('/etc/hostname', 'r') as file:
        data = file.readlines()
    data[0] = newhostname
    with open('temp.txt', 'w') as file:
        file.writelines( data )
    os.system('sudo mv temp.txt /etc/hostname')
    print("done")
    
def sendTomasterInTesting():
    while 1:
        #os.system("sudo killall /home/pi/Documents/GTM_CLIENT/testing_Script_radar.py")
        #import testing_Script_radar as tsr1
        print("sendTomasterInTesting")
        file=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'r')
        status=file.read()
        file.close()
        fil6=open("/home/pi/Documents/GTM_CLIENT/dump/device.txt",'r')
        devi=str(fil6.read())
        fil6.close()
        print(status)
        worksheet="/home/pi/Documents/GTM_CLIENT/dump/TestData/test.txt"
        datash=open(worksheet,'r')
        tag=datash.read()
        datash.close()
        cpu_serial=modal.getserial()
        generalConfig.stage="Sending_data"
        message = generalConfig.stage+";" + str(tag)+";"+status+";"+devi
        response=clcon.transmit(message)
        print("Rep:",response)
        if response == "Ok" :
            file6=open("/home/pi/Documents/GTM_CLIENT/dump/device.txt",'r')
            dev=str(file6.read())
            file6.close()
            print("Dev:",dev)
      
            worksheet="/home/pi/Documents/GTM_CLIENT/dump/TestData/test.txt"
            datash=open(worksheet,'r')
            tag=datash.read()
            datash.close()
            #testing_Script(ser)
            print(tag)
            #print("Data testing going on!")R
            generalConfig.stage="Sending_data"
            msg1=generalConfig.stage+";"+str(tag)+";"+status+";"+devi
            res=clcon.transmit(msg1)
            print(res)
            if res=="Break_Test":
                file1=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'w')
                file1.write("Untested")
                file1.close()
                os.system("sudo reboot")
                break
            if res=="TestDone":
                file1=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'w')
                file1.write("Tested")
                file1.close()
                file3=open("/home/pi/Documents/GTM_CLIENT/dump/Serial_Number.txt",'r')
                ser=file3.read()
                file3.close()
                setHostname(ser)
                os.system("sudo reboot")
                break
            if dev=="Non-Tag":
                import testing_Script_radar as tsr
                Process(target=tsr.testing_Script()).start()
            if dev=="Tag":
                import testing_script as tst
                Process(target=tst.testing_tag()).start()
            if dev=="Dump-Truck":
                import Testing_script_dump_truck as tsd
                Process(target=tsd.testing_Script()).start()

     
def sendTomaster():
    
    file=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'r')
    status=file.read()
    file.close()
    print(status)
    cpu_serial=modal.getserial()
    generalConfig.stage
    message = generalConfig.stage+";" + cpu_serial+";"+status+";NoDevice"
    response=clcon.transmit(message)
    print("Rep:",response)

    if response == "Ok" :
        file6=open("/home/pi/Documents/GTM_CLIENT/dump/device.txt",'r')
        dev=str(file6.read())
        file6.close()
        print("Dev:",dev)
        worksheet="/home/pi/Documents/GTM_CLIENT/dump/TestData/test.txt"
        datash=open(worksheet,'r')
        tag=datash.read()
        datash.close()
        #testing_Script(ser)
        print(tag)
        #print("Data testing going on!")
        generalConfig.stage="Sending_data"
        msg1=generalConfig.stage+";"+str(tag)+";"+status+";NoDevice"
        res=clcon.transmit(msg1)
        print(res)
        
    if(response=="ack1"):
        print("Acknowledgement 1 received!")
        generalConfig.stage="SEND_SN"

        msg1=generalConfig.stage+";nodata;"+status+";NoDevice"
        res=clcon.transmit(msg1)
        print(res)
        dataMessage = res.split(";", 3)
        cmd=dataMessage[0]
        serial_number=dataMessage[1]
        tester_name=dataMessage[2]
        device=dataMessage[3]
        if cmd== "SN_Num":
            print("Acknowledgement 2 received!")
            print("Got Serial Number and Tester Name")
            print("Serial Number",serial_number)
            print("Tested By:",tester_name)
            print("Device Name:",device)
            file3=open("/home/pi/Documents/GTM_CLIENT/dump/Serial_Number.txt",'w')
            file3.write(serial_number)
            file3.close()
            fileser=open("/home/pi/Configuration/Serial.txt",'w')
            fileser.write(serial_number)
            fileser.close()
            file4=open("/home/pi/Documents/GTM_CLIENT/dump/tester_name.txt",'w')
            file4.write(tester_name)
            file4.close()
            filetester=open("/home/pi/Configuration/tester_name.txt",'w')
            filetester.write(tester_name)
            filetester.close()
            file5=open("/home/pi/Documents/GTM_CLIENT/dump/device.txt",'w')
            file5.write(device)
            file5.close()
            file_dev=open("/home/pi/Configuration/DeviceName.txt",'w')
            file_dev.write(device)
            file_dev.close()
            generalConfig.stage="REV_Serial_Tester"
            msg2=generalConfig.stage+";nodata;"+status+";NoDevice"
            res2=clcon.transmit(msg2)
            print(res2)
            file6=open("/home/pi/Documents/GTM_CLIENT/dump/device.txt",'r')
            dev=str(file6.read())
            file6.close()
            print("Dev:",dev)

            if res2=="Start_data_Transfer" and dev=="Non-Tag":
                print("Acknowledgement 3 received!")
                print("Started Non Tag Testing")
                file1=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'w')
                file1.write("under_test")
                file1.close()
                file2=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'r')
                status1=file2.read()
                file2.close()
                generalConfig.stage="Sending_data"
                msg3=generalConfig.stage+";"+"   Date          Time          Distance"+";"+status1+";Non-Tag"
                res3=clcon.transmit(msg3)
                print(res3,"Aya h ye")
                worksheet="/home/pi/Documents/GTM_CLIENT/dump/TestData/test.txt"
                f=open(worksheet,'w')
                f.write(" ")
                f.close()
                print("Idar ko pahucha")
                sendTomasterInTesting()

            if res2=="Start_data_Transfer" and dev=="Dump-Truck":
                print("Acknowledgement 3 received!")
                print("Started Non Tag Testing")
                file1=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'w')
                file1.write("under_test")
                file1.close()
                file2=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'r')
                status1=file2.read()
                file2.close()
                generalConfig.stage="Sending_data"
                msg3=generalConfig.stage+";"+"   Date          Time          Distance"+";"+status1+";Dump-Truck"
                res3=clcon.transmit(msg3)
                print(res3,"Aya h ye")
                worksheet="/home/pi/Documents/GTM_CLIENT/dump/TestData/test.txt"
                f=open(worksheet,'w')
                f.write(" ")
                f.close()
                print("Idar ko pahucha")
                sendTomasterInTesting()    

            if res2=="Start_data_Transfer" and dev=="Tag":
                print("Acknowledgement 3 received!")
                print("Started Tag Testing")
                file1=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'w')
                file1.write("under_test")
                file1.close()
                file2=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'r')
                status1=file2.read()
                file2.close()
                generalConfig.stage="Sending_data"
                msg3=generalConfig.stage+";"+"   Date         Time               Mac-Address          RSSI"+";"+status1+";Tag"
                res3=clcon.transmit(msg3)
                print(res3)
                worksheet="/home/pi/Documents/GTM_CLIENT/dump/TestData/test.txt"
                f=open(worksheet,'w')
                f.write(" ")
                f.close()
                print("Tag k idar")
                sendTomasterInTesting()
            

def testingDoneConfirmation():
    file=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'r')
    status=file.read()
    file.close()
    print(status)
    file6=open("/home/pi/Documents/GTM_CLIENT/dump/device.txt",'r')
    dev=str(file6.read())
    file6.close()
    cpu_serial=modal.getserial()
    generalConfig.stage="Tested"
    message = generalConfig.stage+";" + cpu_serial+";"+status+";"+dev
    response=clcon.transmit(message)
    print("Rep:",response)
    os.system("sudo python3 /home/pi/Documents/Dump_Non_Tag/radar_combined.py")
    


while True:
    try:
        file_st=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'r')
        status=file_st.read()
        file_st.close()
        file_dev=open("/home/pi/Documents/GTM_CLIENT/dump/device.txt",'r')
        devi=file_dev.read()
        file_dev.close()
        if status=="Untested":
            sendTomaster()
            print("Untested")
        if status=="under_test":
            print("Under test")
            sendTomasterInTesting()
        if status=="Tested" and devi == "Dump-Truck":
            os.system("sudo python3 /home/pi/Documents/Dump_Non_Tag/radar_combined.py")
        if status=="Tested" and devi == "Non-Tag":
            os.system("sudo python3 /home/pi/Documents/Dump_Non_Tag/radar_combined.py")
            #testingDoneConfirmation()
            
            
    except :
        #file1=open("/home/pi/Documents/GTM_CLIENT/dump/status.txt",'w')
        #file1.write("Untested")
        #file1.close()
	os.system("sudo python3 /home/pi/Documents/Dump_Non_Tag/radar_combined.py")
        break
        print("Restart")
    #sleep(sleepTime)

