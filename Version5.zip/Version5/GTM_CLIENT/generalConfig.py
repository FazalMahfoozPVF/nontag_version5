host = '192.168.100.37'
port = 5560
stage="cpu_serial"
count=0
