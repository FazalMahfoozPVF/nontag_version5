import RPi.GPIO as GPIO
import time #import sleep

buzzer=37

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(buzzer,GPIO.OUT)# pin for buzzer

class pin():	
	def buzzer_blow():
		GPIO.output(buzzer,GPIO.HIGH)
		time.sleep(0.8)

	
	def buzzer_off():
		GPIO.output(buzzer,GPIO.LOW)
		time.sleep(0.01)

	def buzzer_off1():
		GPIO.output(buzzer,GPIO.LOW)
