
'''#p ('بسم الله')
	Company: Perfect Vision Tech
	Developer: Fazal Mahfooz
	Project: Tag PWAS Version 2
	Description:
	1 Jan 2020
	1-Writen Basic Code for Tag Detection
	2-Getting Card Number and rssi
	3-Ommit other tag numbers
	
	2 Jan 2020
	1- Range set

        4 Jan 2020
        1- Rssi Set for 7 Meters
        2- Added all other features as was in Version 1

        5 Jan 2020
	
	Next Target:With bluetooth sending Operator Tag
	Date: 8 Jan 2020 
	Place: Dammam,KSA
	
https://medium.com/@xpl/protecting-python-sources-using-cython-dcd940bb188e
'''

import controller as con
from pins import *
import time
import subprocess
import re
import calendar;
import datetime
import os
from modal import *
import RPi.GPIO as GPIO

op=open("/home/pi/Configuration/operator.txt",'r')
operator=op.read();
op.close()
print(operator)
def testing_tag():
    worksheet="/home/pi/Documents/GTM_CLIENT/dump/TestData/test.txt"
    os.system("sudo invoke-rc.d bluetooth restart")
    while 1:
        data = con.sock.recv(1027)
        #a=':'.join("{0:02x}".format(x) for x in data[12:10:-1])
        #if a == "ac:23":
        c=':'.join("{0:02x}".format(x) for x in data[12:6:-1])
        if(c == operator):
            pin.buzzer_off()
        if (c!= operator):
            #pin.buzzer_off()
            dd=c[0]+c[1]+c[3]+c[4]
            
                #if a == "ac:23":
                #if c== "ac:23:3f:25:60:1f":
            
            #print("Operator: "+c+" Rssi: "+str(rssi))
            if dd=="ac23":
                rssi = data[-1]
                #print(c, rssi)
                if rssi < 183 and rssi > 178:
                    #pin.buzzer_blow()
                    #return "no-tag"
                    pin.buzzer_off()
                if rssi >= 183 :
                    pin.buzzer_blow()
                    ttt = time.time()
                    tt =  datetime.datetime.fromtimestamp(ttt).strftime('%H:%M:%S')
                    dt =  datetime.datetime.fromtimestamp(ttt).strftime('%d-%m-%Y')
                    #tie=open("/home/pi/Documents/Tag_v2/dump/time.txt",'w')
                    #tie.write(tt)
                    #tie.close()
                    f=open(worksheet,'w')
                    f.write(str(dt)+"|"+str(tt)+"|"+str(c)+"|"+str(rssi))#+"                "+str(t)+"             "+str(tt)+"\n")
                    f.close()
                    #print(c)
                    break
                    #return c,dt,tt
                else:
                    #return "no-tag"
                    pin.buzzer_off()
                
            else:
                #return "no-tag"
                pin.buzzer_off()




#testing_tag()
#main()
