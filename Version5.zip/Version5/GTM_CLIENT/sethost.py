import os
def setHostname(newhostname):
    with open('/etc/hosts', 'r') as file:
        data = file.readlines()
        data[5] = '127.0.1.1       ' + newhostname
    with open('temp.txt', 'w') as file:
        file.writelines( data )
    os.system('sudo mv temp.txt /etc/hosts')
    with open('/etc/hostname', 'r') as file:
        data = file.readlines()
    data[0] = newhostname
    with open('temp.txt', 'w') as file:
        file.writelines( data )
    os.system('sudo mv temp.txt /etc/hostname')

setHostname('done')
