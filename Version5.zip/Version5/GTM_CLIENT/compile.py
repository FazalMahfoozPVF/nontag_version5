from distutils.core import setup
from distutils.extension import Extension
from Cython.Distutils import build_ext
ext_modules = [
    Extension("testing_script",  ["testing_script.py"]),
Extension("Testing_script_dump_truck",  ["Testing_script_dump_truck.py"]),
Extension("testing_Script_radar",  ["testing_Script_radar.py"]),
Extension("Client_1",  ["Client_1.py"]),
#   ... all your modules that need be compiled ...
]
setup(
    name = 'Testing Script',
    cmdclass = {'build_ext': build_ext},
    ext_modules = ext_modules
)
